
var navigator = {
    qt: {
        callMethod: function (payload) {
            return "{}";
        }
    }
};

module.exports = navigator;

